package sem3;

public class Sem3 {

    public static void main(String[] args) {
        InterfazGrafic Grafic = new InterfazGrafic();
        Grafic.setVisible(true);
    }
    
}
